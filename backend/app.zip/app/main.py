import logging
import os
from contextlib import asynccontextmanager
from datetime import datetime

from fastapi import FastAPI, Request, status
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.exceptions import HTTPException as StarletteHTTPException

from app.database.connection import engine
from app.database.base import Base
from app.models import user, watchlist
from app.models import reminder as reminder_models
from app.models import password_reset as password_reset_models
from app.routers import auth, movies, watchlist as watchlist_router
from app.routers import mood as mood_router
from app.routers import reminder as reminder_router
from app.routers import recommendations as recommendations_router  # ← THÊM MỚI
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.executors.pool import ThreadPoolExecutor

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("films")


# ════════════════════════════════════════════
# SCHEDULER JOB
# ════════════════════════════════════════════

def _run_check_and_fire():
    from app.database.connection import SessionLocal
    from app.services.reminder_service import check_and_fire
    db = SessionLocal()
    try:
        fired = check_and_fire(db)
        logger.info(f"[scheduler] reminder check_and_fire → {fired} fired")
    except Exception as e:
        logger.error(f"[scheduler] reminder error: {e}")
    finally:
        db.close()


# ════════════════════════════════════════════
# REQUEST SIZE GUARD MIDDLEWARE
# ════════════════════════════════════════════

class RequestSizeMiddleware(BaseHTTPMiddleware):
    def __init__(self, app, max_bytes: int = 64 * 1024):
        super().__init__(app)
        self.max_bytes = max_bytes

    async def dispatch(self, request: Request, call_next):
        content_length = request.headers.get("content-length")
        if content_length and int(content_length) > self.max_bytes:
            return JSONResponse(
                status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                content={
                    "error":   "Request quá lớn",
                    "message": f"Kích thước tối đa là {self.max_bytes // 1024} KB.",
                },
            )
        return await call_next(request)


# ════════════════════════════════════════════
# LIFESPAN
# ════════════════════════════════════════════

@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)
    logger.info("🎬 Films API v2.3 starting up...")

    scheduler = BackgroundScheduler(
        timezone="Asia/Ho_Chi_Minh",
        executors={"default": ThreadPoolExecutor(max_workers=1)},
        job_defaults={
            # Nếu server restart và bỏ lỡ lần chạy, cho phép chạy bù trong 10 phút
            "misfire_grace_time": 600,
            # Không chạy chồng nhau nếu job trước chưa xong
            "coalesce": True,
            "max_instances": 1,
        },
    )
    scheduler.add_job(
        _run_check_and_fire,
        trigger="interval",
        minutes=10,
        id="reminder_check",
        # Chạy ngay lần đầu khi startup thay vì đợi 10 phút
        next_run_time=datetime.now(tz=scheduler.timezone),
    )

    if not scheduler.running:
        scheduler.start()
        logger.info("🔔 Reminder scheduler started (interval: 10 min).")

    yield

    scheduler.shutdown(wait=False)
    logger.info("Films API shutting down.")


# ════════════════════════════════════════════
# APP
# ════════════════════════════════════════════

app = FastAPI(
    title="Films API",
    description="Movie Discovery & Watchlist API",
    version="2.3.0",
    lifespan=lifespan,
)

app.add_middleware(RequestSizeMiddleware, max_bytes=64 * 1024)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Global exception handlers ─────────────

@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    errors = []
    for err in exc.errors():
        field = " → ".join(str(loc) for loc in err["loc"] if loc != "body")
        errors.append({
            "field":   field or "body",
            "message": err["msg"].replace("Value error, ", ""),
            "type":    err["type"],
        })
    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content={"error": "Dữ liệu không hợp lệ", "details": errors},
    )


@app.exception_handler(StarletteHTTPException)
async def http_exception_handler(request: Request, exc: StarletteHTTPException):
    detail = exc.detail
    if isinstance(detail, dict):
        return JSONResponse(
            status_code=exc.status_code, content=detail,
            headers=getattr(exc, "headers", None) or {},
        )
    return JSONResponse(
        status_code=exc.status_code, content={"error": detail},
        headers=getattr(exc, "headers", None) or {},
    )


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    logger.exception(f"Unhandled error on {request.method} {request.url}: {exc}")
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={"error": "Lỗi máy chủ nội bộ. Vui lòng thử lại sau."},
    )


# ── Routers ───────────────────────────────

app.include_router(auth.router)
app.include_router(movies.router)
app.include_router(watchlist_router.router)
app.include_router(mood_router.router)
app.include_router(reminder_router.router)
app.include_router(recommendations_router.router)   # ← THÊM MỚI


@app.get("/")
def root():
    return {"message": "Films API v2.3 running", "docs": "/docs"}


@app.get("/health")
def health(request: Request):
    from app.utils.rate_limit import limiter
    return {"status": "ok", "rate_limiter": limiter.stats()}